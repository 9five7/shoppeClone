import RatingStart from "./RatingStart";

export default RatingStart