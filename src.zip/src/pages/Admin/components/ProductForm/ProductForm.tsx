import { useForm } from 'react-hook-form'
import Button from 'src/components/Button'

import Input from 'src/components/Input'

export default function ProductForm({ initialValues, onSubmit, onCancel }) {
  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm({
    defaultValues: initialValues || {
      name: '',
      price: '',
      quantity: '',
      description: ''
    }
  })

  return (
    <form onSubmit={handleSubmit(onSubmit)} className='space-y-4'>
      <div>
        <label className='block text-sm font-medium'>Tên sản phẩm</label>
        <Input
          type='text'
          {...register('name', { required: 'Tên sản phẩm là bắt buộc' })}
          className='w-full px-3 py-2 border rounded focus:outline-none focus:ring'
        />
        {errors.name && <p className='text-red-500 text-sm mt-1'>{errors.name.message}</p>}
      </div>
      <div>
        <label className='block text-sm font-medium'>Giá</label>
        <input
          type='number'
          {...register('price', { required: 'Giá sản phẩm là bắt buộc' })}
          className='w-full px-3 py-2 border rounded focus:outline-none focus:ring'
        />
        {errors.price && <p className='text-red-500 text-sm mt-1'>{errors.price.message}</p>}
      </div>
      <div>
        <label className='block text-sm font-medium'>Số lượng</label>
        <input
          type='number'
          {...register('quantity', { required: 'Số lượng là bắt buộc' })}
          className='w-full px-3 py-2 border rounded focus:outline-none focus:ring'
        />
        {errors.quantity && <p className='text-red-500 text-sm mt-1'>{errors.quantity.message}</p>}
      </div>
      <div>
        <label className='block text-sm font-medium'>Mô tả</label>
        <textarea
          {...register('description', { required: 'Mô tả là bắt buộc' })}
          className='w-full px-3 py-2 border rounded focus:outline-none focus:ring'
        ></textarea>
        {errors.description && <p className='text-red-500 text-sm mt-1'>{errors.description.message}</p>}
      </div>
      <div className='flex justify-end space-x-2'>
        <Button type='button' onClick={onCancel} className='bg-gray-500 text-white px-4 py-2'>
          Hủy
        </Button>
        <Button type='submit' className='bg-blue-500 text-white px-4 py-2'>
          Lưu
        </Button>
      </div>
    </form>
  )
}
