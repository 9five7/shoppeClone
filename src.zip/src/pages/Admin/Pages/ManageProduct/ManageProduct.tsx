import { useState, useEffect } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import Button from 'src/components/Button';
import Modal from 'src/components/Modal';

import { toast } from 'react-toastify';
import { Product, ProductList } from 'src/types/product.type';
import adminProductApi from 'src/apis/adminProduct.api';
import ProductForm from '../../components/ProductForm';

export default function ProductManagement() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Fetch products
  const { data: productsData, refetch } = useQuery<ProductList>({
    queryKey: ['products'],
    queryFn: adminProductApi.getProducts
  });

  // Add or update product
  const productMutation = useMutation({
    mutationFn: (product: Omit<Product, '_id' | 'createdAt' | 'updatedAt'>) => {
      return editingProduct
        ? adminProductApi.updateProduct(editingProduct._id, product)
        : adminProductApi.addProduct(product);
    },
    onSuccess: () => {
      toast.success(editingProduct ? 'Sản phẩm đã được cập nhật!' : 'Sản phẩm đã được thêm!');
      refetch();
      setIsModalOpen(false);
      setEditingProduct(null);
    },
    onError: () => {
      toast.error('Có lỗi xảy ra, vui lòng thử lại.');
    }
  });

  // Delete product
  const deleteProductMutation = useMutation({
    mutationFn: (productId: string) => adminProductApi.deleteProduct(productId),
    onSuccess: () => {
      toast.success('Sản phẩm đã được xóa!');
      refetch();
    },
    onError: () => {
      toast.error('Không thể xóa sản phẩm, vui lòng thử lại.');
    }
  });

  const handleAddProduct = () => {
    setEditingProduct(null);
    setIsModalOpen(true);
  };

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
    setIsModalOpen(true);
  };

  const handleDeleteProduct = (productId: string) => {
    if (window.confirm('Bạn có chắc chắn muốn xóa sản phẩm này?')) {
      deleteProductMutation.mutate(productId);
    }
  };

  const handleModalClose = () => {
    setIsModalOpen(false);
    setEditingProduct(null);
  };

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-4">
        <h1 className="text-xl font-bold">Quản lý sản phẩm</h1>
        <Button className="bg-blue-500 text-white px-4 py-2" onClick={handleAddProduct}>
          Thêm sản phẩm
        </Button>
      </div>
      <div className="bg-white shadow rounded">
        <table className="w-full table-auto">
          <thead>
            <tr className="bg-gray-100">
              <th className="px-4 py-2">#</th>
              <th className="px-4 py-2">Tên sản phẩm</th>
              <th className="px-4 py-2">Giá</th>
              <th className="px-4 py-2">Số lượng</th>
              <th className="px-4 py-2">Hành động</th>
            </tr>
          </thead>
          <tbody>
            {productsData?.products.map((product, index) => (
              <tr key={product._id} className="border-t">
                <td className="px-4 py-2 text-center">{index + 1}</td>
                <td className="px-4 py-2">{product.name}</td>
                <td className="px-4 py-2">₫{product.price}</td>
                <td className="px-4 py-2 text-center">{product.quantity}</td>
                <td className="px-4 py-2 text-center">
                  <Button className="mr-2 bg-yellow-500 text-white px-2 py-1" onClick={() => handleEditProduct(product)}>
                    Chỉnh sửa
                  </Button>
                  <Button className="bg-red-500 text-white px-2 py-1" onClick={() => handleDeleteProduct(product._id)}>
                    Xóa
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {productsData?.products.length === 0 && (
          <div className="text-center py-4 text-gray-500">Chưa có sản phẩm nào.</div>
        )}
      </div>
      {isModalOpen && (
        <Modal onClose={handleModalClose}>
          <ProductForm
            initialValues={editingProduct}
            onSubmit={(values) => productMutation.mutate(values)}
            onCancel={handleModalClose}
          />
        </Modal>
      )}
    </div>
  );
}
