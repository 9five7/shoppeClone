import ManageProduct from "./ManageProduct";

export default ManageProduct