import ProductDetail from "./ProductDetail";

export default ProductDetail