import UserLayout from './UserLayout'

export default UserLayout
