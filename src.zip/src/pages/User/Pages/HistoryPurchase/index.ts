import HistoryPurchsae from './HistoryPurchsae'

export default HistoryPurchsae
