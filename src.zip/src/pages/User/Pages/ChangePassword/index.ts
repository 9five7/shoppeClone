import ChangePassword from './ChangePassword'

export default ChangePassword
