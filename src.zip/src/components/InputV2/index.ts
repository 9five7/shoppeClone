import InputV2 from "./InputV2";

export default InputV2