import { Product } from 'src/types/product.type'
import { SuccessResponse } from 'src/types/utils.type'
import http from 'src/utils/http'
const URL = 'Products'
const adminProductApi = {
  getProducts(params: Product) {
    return http.get<SuccessResponse<Product>>(URL, { params })
  },
  addProduct(body: Omit<Product, '_id'>) {
    return http.post<SuccessResponse<Product>>('/admin/products', body)
  },
  updateProduct(productId: string, body: Partial<Omit<Product, '_id'>>) {
    return http.put<SuccessResponse<Product>>(`/admin/products/${productId}`, body)
  },
  deleteProduct(productId: string) {
    return http.delete<SuccessResponse<null>>(`/admin/products/delete/${productId}`)
  },
  deleteManyProducts(productIds: string[]) {
    return http.delete<SuccessResponse<null>>(`/admin/products/delete-many`, {
      data: { list_id: productIds }
    })
  }
}

export default adminProductApi
