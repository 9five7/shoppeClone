const path = {
  home: '/',
  user:'/user',
  admin: '/admin',
  adminProducts: '/admin/products',
  adminAddProduct: '/admin/products/add',
  adminEditProduct: '/admin/products/edit/:productId',
  profile: '/user/profile',
  changePassword:'/user/Password',
  historyPurchase:'/user/Purchase',
  login: '/login',
  register: '/register',
  logout: '/logout',
  productDetail:':nameId',
  cart:'/cart'
} as const

export default path
